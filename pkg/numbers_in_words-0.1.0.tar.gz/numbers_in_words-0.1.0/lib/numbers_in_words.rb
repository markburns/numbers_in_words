require 'rubygems'

$LOAD_PATH.unshift File.expand_path(File.join(File.dirname(__FILE__)))

require 'numbers'
require 'words'


