require 'rubygems'

$LOAD_PATH.unshift File.expand_path(File.join(File.dirname(__FILE__), 'lib'))

require 'lib/numbers_in_words'
require 'lib/words_in_numbers'


